The .scss (Sass) files are only available in the pro version.
You can buy it from: https://bootstrapmade.com/gp-free-multipurpose-html-bootstrap-template/